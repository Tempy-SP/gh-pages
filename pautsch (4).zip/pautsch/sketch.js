let x =25;
let y =25;
function setup() {
  createCanvas(400, 400); 
 noLoop(); 
  
  colorMode(HSB);
}
function draw() {
      

  background(0);
  
  //rays from space ship
     for(let i =0;i<=50;i++){
       fill(x / 3, 90, 90);
       stroke(x / 3, 90, 90);
       circle(y+width/2, (height/2)+i, 30);
       y+=10;
          if (y > width + 25) {
    y = -25;
  }
       //reset stroke
       stroke(0);
       //create stars
     }
    if(x<width/2){ 
      fill(220);
      circle(x-30,20,20);
      circle(x+100,140,20);
      circle(x+40,350,20);
      rect(x+20,height-300,10,10);
      rect(x+80,height-100,10,10);
      rect(x+120,height-370,10,10);
      rect(x+220,height-70,10,10);
      rect(x+250,height-30,10,10);
      rect(x+20,height-70,10,10);
      fill(70,255,255);
      circle(x+150,40,20);
      circle(x+50,90,20);
      circle(x+90,375,20);
      circle(x+200,330,20);
      rect(x-50,height-300,10,10);
      rect(x,height-45,10,10);
      rect(x+40,height-350,10,10);
      rect(x+100,height-60,10,10);
      rect(x+300,height-320,10,10);
      rect(x+200,height-280,10,10);
     
    }
    if(x>width/2){  
 
  fill(220);
      circle(x-75,20,20);
      circle(x-175,140,20);
      circle(x-275,350,20);
      rect(x-20,height-300,10,10);
      rect(x-80,height-100,10,10);
      rect(x-120,height-370,10,10);
      rect(x-220,height-70,10,10);
      rect(x-250,height-30,10,10);
      rect(x-20,height-70,10,10);
      fill(70,255,255);
      circle(x-150,260,20);
      circle(x-175,310,20);
      circle(x-240,80,20);
      rect(x+50,height-300,10,10);
      rect(x,height-45,10,10);
      rect(x-40,height-350,10,10);
      rect(x-100,height-60,10,10);
      rect(x-300,height-320,10,10);
      rect(x-200,height-280,10,10);
    }
    //fr reset
 x+=5;  
      if (x > width + 25) {
    x = -25;
  }
  
  
 //draw rocket ship
  fill(220);
  ellipse(170,220,250,110);
  fill(200,250,250);
  circle(130,220,50);
  fill(0,255,255);
  triangle(200,273,280,245,350,320);
  triangle(200,168,280,195,350,120);
  triangle(55,200,55,240,20,220);
  fill('gray');
  rect(285,200,20,40);

}
//looping animation
function mousePressed() {
    if (isLooping()) {
    noLoop();
  } else {
    loop();
  }
}
function keyPressed() {
  // Draw one frame
  redraw();
}


