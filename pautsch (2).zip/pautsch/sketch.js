
// initialize variables
let mx = 0;
let my = 0;
let px = 0;
let py = 0;
let fr = 0;


//setup function
function setup() {

	createCanvas(400, 400);
    background(10);

	strokeWeight(4);
	stroke(0, 102);
	let fr = 30;
	frameRate(fr);
  //background gradient
  let c1 = color(0, 0, 0); // black
  let c2 = color(0, 0, 255); // Blue
  for (let y = 0; y < height; y++) {
    let inter = map(y, 0, height, 0, 1);
    let c = lerpColor(c1, c2, inter);
    stroke(c);
    line(0, y, width, y);
  }
}
function draw() { 
 //set background to graiedent colors 

// set new frame rate based on a math function
	 fr = sqrt(200);
	frameRate(fr);

	print(fr);

// set variables to follow mouse 
	let mx = mouseX;
	let my = mouseY;
	let px = pmouseX;
	let py = pmouseY;
//weight base on a math function
	let weight = dist(mx, my, px, py);
  
//color mouse path in gradient 
  //line gradient
	let d1 = color(255,0,0)//red
	let d2 = color(255,255,100);//yellow
for (let y = 0; y < my; y++) {
    let inter = map(y, 0, height, 0, 1);
    let c = lerpColor(d1, d2, inter);
    strokeWeight (weight);
	stroke(c);
    line(px, my, mx, py);
  }
 keyIsPressed(
 rect(mx,my,)
 );

}